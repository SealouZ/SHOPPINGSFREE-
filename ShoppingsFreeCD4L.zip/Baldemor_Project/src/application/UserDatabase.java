package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

public class UserDatabase {
	private String name;
	private ArrayList<User> users;
	public static double totalRevenue;
	
	
	// Constructor
	public UserDatabase(String name) {
		this.name = name;
		this.users = new ArrayList<User>();
		totalRevenue = 0;
	}
	
	
	// Getters & Setters
	public String getName() { return this.name; }
	public ArrayList<User> getUsers() { return new ArrayList<>(users); }
	
	
	// Methods
	public boolean addManager(Manager manager) {		// Poly
		return addUser(manager);
	}

	public boolean addClerk(Clerk clerk) {		// Poly
		return addUser(clerk);
	}

	private boolean addUser(User user) {
		if (user == null || findUser(user.getUsername()) != null) return false;
		users.add(user);
		return true;
	}
	
	public boolean removeUser(User user) {
		return users.remove(user);
	}

	public User findUser(String username) {
		if (username == null) return null;
		for (User user : users) {
			if (user.getUsername().equalsIgnoreCase(username)) return user;
		}
		return null;
	}
	
	public User login(String username, String password) {
		User user = findUser(username);
		if (user != null && user.getPassword().equals(password)) return user;
		return null;
	}
	
	public void saveData(Path saveFile) {
		System.out.println("\n\nSaving Users. . .");
		try (BufferedWriter writer = Files.newBufferedWriter(saveFile)){
			Files.createDirectories(saveFile.getParent());
			writer.write(String.valueOf(totalRevenue));
			writer.newLine();
			for (User user: this.users) {
				writer.write(String.join("|", user.getUsername(), user.getName(), user.getUserType(), user.getPassword()));
				writer.newLine();
			}
			System.out.println("Users Saved");
		} catch (IOException e) {
			System.out.println("Save Unsuccessful");
		}
	}
	
	public void loadData(Path saveFile) {
		System.out.println("\nLoading Users. . .");
		this.users.clear();
		BufferedReader reader;
		try {
			reader = Files.newBufferedReader(saveFile);
			String line = reader.readLine();
			totalRevenue = Double.parseDouble(line);
			while ((line = reader.readLine()) != null) {
				String[] person = line.split("\\|", -1);
				if (person[2].equals("Manager")) {
					this.users.add(new Manager(person[0], person[1], person[2], person[3]));
					System.out.println("Manager Added");
				} else if (person[2].equals("Clerk")) {
					this.users.add(new Clerk(person[0], person[1], person[2], person[3]));
					System.out.println("Clerk Added");
				}
			}
		} catch (IOException e) {
			System.out.println("Load Unsuccessful");
		}
	}
	
}
