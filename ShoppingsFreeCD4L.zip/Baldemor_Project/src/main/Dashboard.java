package main;

import application.*;
import java.util.Comparator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Dashboard extends BorderPane{
	private final AppSystem appSystem;
	private final Stage stage;
	private User currentUser;
	private Manager managerSession;
	
	public Dashboard(AppSystem appSystem, Stage stage) {
		this.appSystem = appSystem;
		this.stage = stage;
		setPadding(new Insets(20));
		showLogin();
	}
	
	public void showLogin() {
		Label title = new Label("SHOPPINGSFREE");
		title.getStyleClass().add("page-title");
		TextField username = new TextField();
		username.setPromptText("Username");
		PasswordField password = new PasswordField();
		password.setPromptText("Password");
		Button login = new Button("Log In");
		login.setDefaultButton(true);		// Enter
		
		login.setOnAction(event -> {
			User user = appSystem.login(username.getText().trim(), password.getText());
			currentUser = user;
			if (user instanceof Manager) {
				managerSession = (Manager) user;
				showManagerDashboard();
			} else if (user instanceof Clerk) {
				managerSession = null;
				showClerkDashboard();
			} else {
				Alert alert = new Alert(Alert.AlertType.ERROR, "Login Failed");
				alert.showAndWait();
			}
		});
		VBox form = new VBox(12, title, new Label("Log In"), username, password, login);
		form.setMaxWidth(360);
		form.setAlignment(Pos.CENTER);
		form.getStyleClass().add("login-form");
		setCenter(form);
	}
	
	// Constant head
	private VBox header(Label heading) {
		ImageView logo = new ImageView();
		var logoURL = getClass().getResource("/application/SHOPPINGSFREE_LOGO_transparent.png");
		if (logoURL != null) {
			logo.setImage(new Image(logoURL.toExternalForm()));
			logo.setFitWidth(280);
			logo.setFitHeight(80);
			logo.setPreserveRatio(true);
			logo.setSmooth(true);
		}
		Button backToManager = new Button("Back to Manager");
		backToManager.setOnAction(e -> {
			currentUser = managerSession;
			showManagerDashboard();
		});

		Button logout = new Button("Log Out");
		logout.setOnAction(e -> {
			currentUser = null;
			managerSession = null;
			showLogin();
		});

		Region spacer = new Region();
		HBox row = new HBox(18, logo, heading, spacer);
		// Only show this button when a manager is viewing a clerk dashboard
		if (managerSession != null && currentUser instanceof Clerk) {
			row.getChildren().add(backToManager);
		}
		row.getChildren().add(logout);
		HBox.setHgrow(spacer, Priority.ALWAYS);
		row.setAlignment(Pos.CENTER_LEFT);
		row.setPadding(new Insets(0, 0, 16, 0));
		return new VBox(row);
	}

	private Tab tab(String name, javafx.scene.Node content) {
		Tab tab = new Tab(name, content);
		tab.setClosable(false);
		return tab;
	}
	
	private void saveAndRefresh(TableView<Product> table) { appSystem.saveAll(); refreshProducts(table); }
	
	private VBox content(javafx.scene.Node table, javafx.scene.Node controls) {
		VBox box = new VBox(12, table, controls); box.setPadding(new Insets(16));
		if (table instanceof TableView<?>) VBox.setVgrow(table, Priority.ALWAYS); return box;
	}
	
	private TableView<Product> productTable() {
		TableView<Product> table = new TableView<>();
		table.getColumns().add(column("Product ID", "id", 120));
		table.getColumns().add(column("Product", "name", 180));
		table.getColumns().add(column("Price", "price", 100));
		table.getColumns().add(column("Stock", "stock", 90));
		table.getColumns().add(column("Description", "description", 260));
		refreshProducts(table); 
		return table;
	}
	
	private void refreshProducts(TableView<Product> table) { 
		table.setItems(FXCollections.observableArrayList(appSystem.getInventory().getItems().values())); 
	}
	
	private boolean confirm(String message) { 
		Alert alert = new Alert(Alert.AlertType.CONFIRMATION, message, ButtonType.YES, ButtonType.NO); 
		alert.setHeaderText(null); 
		return alert.showAndWait().orElse(ButtonType.NO) == ButtonType.YES; 
	}
	
	private VBox managerInventoryTab() {
		TableView<Product> table = productTable();
		Button addProduct = new Button("Add Product");
		Button restockProduct = new Button("Restock Selected");
		Button removeProduct = new Button("Remove Selected");
		
		addProduct.setOnAction(e -> {
			TextField id = new TextField(); id.setPromptText("Product ID");
			TextField name = new TextField(); name.setPromptText("Product name");
			TextField price = new TextField(); price.setPromptText("Unit price");
			TextField stock = new TextField(); stock.setPromptText("Initial stock");
			TextField description = new TextField(); description.setPromptText("Description");
			VBox fields = new VBox(8, id, name, price, stock, description);
			Dialog<ButtonType> dialog = new Dialog<>();
			dialog.setTitle("Add Product"); dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
			dialog.getDialogPane().setContent(fields);
			if (dialog.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
				try {
					Product p = new Product(id.getText().trim(), name.getText().trim(), Integer.parseInt(price.getText()), Integer.parseInt(stock.getText()), description.getText());
					if (id.getText().isBlank() || name.getText().isBlank() || Integer.parseInt(price.getText()) < 0 || Integer.parseInt(stock.getText()) < 0 || !((Manager) currentUser).addProduct(appSystem.getInventory(), p)) throw new IllegalArgumentException();
					saveAndRefresh(table);
				} catch (RuntimeException ex) { 
					Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid product, Enter a unique ID, a name, and valid non-negative price and stock values."); 
					alert.showAndWait();
				}
			}
		});
		
		restockProduct.setOnAction(e -> {
			Product product = table.getSelectionModel().getSelectedItem();
			if (product == null) { 
				Alert alert = new Alert(Alert.AlertType.ERROR, "No selection, Select a product first."); 
				alert.showAndWait();
				return;
			}
			TextInputDialog dialogue = new TextInputDialog("1"); dialogue.setTitle("Restock Product"); dialogue.setHeaderText("Additional quantity");
			dialogue.showAndWait().ifPresent(value -> { 
				try { 
					if (!((Manager) currentUser).restockProduct(product, Integer.parseInt(value))) throw new IllegalArgumentException(); saveAndRefresh(table); } catch (RuntimeException ex) { 
						Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid quantity, Enter a positive whole number."); 
						alert.showAndWait();
					} 
				});
		});
		
		removeProduct.setOnAction(e -> {
			Product product = table.getSelectionModel().getSelectedItem();
			if (product == null) { 
				Alert alert = new Alert(Alert.AlertType.ERROR, "No selection, Select a product first."); 
				alert.showAndWait();
				return;
			}
			boolean usedInHistory = appSystem.getAllTransactions().stream()
					.anyMatch(t -> t.getProduct() != null && t.getProduct().getId().equals(product.getId()));
			if (usedInHistory) {
				Alert alert = new Alert(Alert.AlertType.ERROR, "Product has transaction history"); 
				alert.showAndWait();
				return;
			}
			if (confirm("Remove " + product.getName() + " from inventory?")) { 
				((Manager) currentUser).removeProduct(appSystem.getInventory(), product); saveAndRefresh(table); 
		   }
		});
		Button refresh = new Button("Refresh");
		refresh.setOnAction(e -> refreshProducts(table));
		return content(table,new HBox(10, addProduct, restockProduct, removeProduct, refresh));
	}
	
	// Manager only
	private void showManagerDashboard() {
		Label heading = new Label("Manager Dashboard — " + currentUser.getName());
		heading.getStyleClass().add("page-title");
		TabPane tabs = new TabPane();
		tabs.getTabs().add(tab("Inventory", managerInventoryTab()));
		tabs.getTabs().add(tab("Clerk Management", clerkManagementTab()));
		tabs.getTabs().add(tab("Transactions", transactionTab(false)));
		tabs.getTabs().add(tab("Global History", transactionTab(true)));
		setTop(header(heading));
		setCenter(tabs);
	}
		
	private void showClerkDashboard() {
		Label heading = new Label("Clerk Dashboard — " + currentUser.getName());
		heading.getStyleClass().add("page-title");
		TabPane tabs = new TabPane();
		tabs.getTabs().add(tab("Inventory Checker", inventoryCheckerTab()));
		tabs.getTabs().add(tab("Transactions", clerkSalesTab()));
		tabs.getTabs().add(tab("Transaction History", transactionTab(true)));
		setTop(header(heading));
		setCenter(tabs);
	}
	
	private void refreshClerks(TableView<Clerk> table) { 
		table.setItems(FXCollections.observableArrayList(((Manager) currentUser).getClerks(appSystem.getUserDatabase()))); 
	}
	
	private VBox clerkManagementTab() {
		TableView<Clerk> table = clerkTable();
		Button add = new Button("Add Clerk");
		Button remove = new Button("Remove Selected Clerk");
		Button openDashboard = new Button("Open Dashboard");
		Button refresh = new Button("Refresh");
		refresh.setOnAction(e -> { refreshClerks(table); });

		openDashboard.setOnAction(e -> {
			Clerk clerk = table.getSelectionModel().getSelectedItem();
			if (clerk == null) {
				Alert alert = new Alert(Alert.AlertType.ERROR, "Select a clerk first.");
				alert.showAndWait();
				return;
			}
			currentUser = clerk;
			showClerkDashboard();
		});
		
		add.setOnAction(e -> {
			TextField username = new TextField(); username.setPromptText("Username");
			TextField name = new TextField(); name.setPromptText("Full name");
			PasswordField password = new PasswordField(); password.setPromptText("Temporary password");
			VBox fields = new VBox(8, username, name, password);
			Dialog<ButtonType> d = new Dialog<>(); d.setTitle("Create Clerk Account"); d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL); d.getDialogPane().setContent(fields);
			if (d.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
				if (appSystem.signup(username.getText(), name.getText(), password.getText(), "Clerk") == null) {
					Alert alert = new Alert(Alert.AlertType.ERROR, "Unable to add clerk, Complete all fields"); 
					alert.showAndWait();
				}
				refreshClerks(table);
			}
		});
		
		remove.setOnAction(e -> {
			Clerk clerk = table.getSelectionModel().getSelectedItem();
			if (clerk == null) { 
				Alert alert = new Alert(Alert.AlertType.ERROR, "No selection, Select a clerk first."); 
				alert.showAndWait();
				return;
			}
			if (!clerk.getTransactions().isEmpty()) {
				Alert alert = new Alert(Alert.AlertType.ERROR, "Clerk has transaction history"); 
				alert.showAndWait();
				return;
			}
			if (confirm("Remove clerk account " + clerk.getUsername() + "?")) {
				appSystem.getUserDatabase().removeUser(clerk); appSystem.saveAll(); refreshClerks(table);
			}
		});
		return content(table,new HBox(10, add, remove, openDashboard, refresh));
	}
	
	private TableView<Clerk> clerkTable() {
		TableView<Clerk> table = new TableView<>();
		table.getColumns().add(column("Username", "username", 150));
		table.getColumns().add(column("Name", "name", 220));
		table.getColumns().add(column("Sales", "sales", 120));
		refreshClerks(table); return table;
	}
	
	private VBox clerkSalesTab() {
		TableView<Product> products = productTable();
		TextField quantity = new TextField(); quantity.setPromptText("Quantity");
		TextField payment = new TextField(); payment.setPromptText("Payment amount");
		Button sell = new Button("Record Sale");
		sell.setOnAction(e -> {
			Product product = products.getSelectionModel().getSelectedItem();
			if (product == null) {  
				Alert alert = new Alert(Alert.AlertType.ERROR, "No product selected"); 
				alert.showAndWait();
				return; 
			}
			try {
				int qty = Integer.parseInt(quantity.getText()); double paid = Double.parseDouble(payment.getText());
				double total = (double) product.getPrice() * qty;
				if (qty <= 0 || paid < total) { 
					Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid sale, insufficient quantity/payment"); 
					alert.showAndWait();
					return; 
				}
				Transaction transaction = currentUser.sellItem(product, qty, paid);
				if (transaction == null) { 
					Alert alert = new Alert(Alert.AlertType.ERROR, "Sale failed, check stock"); 
					alert.showAndWait();
					return; 
				}
				appSystem.saveAll(); 
				refreshProducts(products);
				Alert alert = new Alert(Alert.AlertType.INFORMATION); 
				alert.setTitle("Sale recorded"); 
				alert.setContentText("Transaction " + transaction.getId() + "\nTotal: " + transaction.getTotalAmount() + "\nChange: " + transaction.getChange()); 
				alert.showAndWait();
				quantity.clear(); 
				payment.clear();
			} catch (NumberFormatException ex) { 
				Alert alert = new Alert(Alert.AlertType.ERROR, "Invalid Input, enter whole number & valid payment amount"); 
				alert.showAndWait();
			}
		});
		Button refresh = new Button("Refresh Inventory");
		refresh.setOnAction(e -> { refreshProducts(products); });
		return content(products, new HBox(10, quantity, payment, sell, refresh));
	}
	
	private VBox transactionTab(boolean historyOnly) {
		boolean global = currentUser instanceof Manager;
		TableView<Transaction> table = transactionTable(global);
		Button refresh = new Button("Refresh"); refresh.setOnAction(e -> refreshTransactions(table, global));
		Button voidButton = new Button("Void Selected Transaction");
		voidButton.setOnAction(e -> {
			Transaction transaction = table.getSelectionModel().getSelectedItem();
			if (transaction == null) { 
				Alert alert = new Alert(Alert.AlertType.ERROR, "No selection"); 
				alert.showAndWait();
				return; 
			}
			if (transaction.isVoided()) { 
				Alert alert = new Alert(Alert.AlertType.ERROR, "Already voided"); 
				alert.showAndWait();
				return; 
			}
			if (confirm("Void transaction " + transaction.getId() + "? Stock and sales totals will be reversed.")) {
				if (appSystem.voidTransaction(transaction.getId())) { appSystem.saveAll(); refreshTransactions(table, global); }
				else {
					Alert alert = new Alert(Alert.AlertType.ERROR, "Unable to void"); 
					alert.showAndWait();
				}
			}
		});
		if (currentUser instanceof Clerk) {
			return content(table, refresh);
		}
		if (global && historyOnly) {
			return globalHistoryTab(table, refresh);
		}
		return historyOnly ? content(table, refresh) : content(table, new HBox(10, refresh, voidButton));
	}
	
	private VBox globalHistoryTab(TableView<Transaction> table, Button refresh) {
			Label title = new Label("Total Revenue");
			title.getStyleClass().add("revenue-title");
			Label revenue = new Label();
			revenue.getStyleClass().add("revenue-value");
			Runnable updateRevenue = () -> {
				double total = appSystem.getAllTransactions().stream().filter(transaction -> !transaction.isVoided()).mapToDouble(Transaction::getTotalAmount).sum();revenue.setText(String.format("₱%,.2f", total));
			};
			updateRevenue.run();

			refresh.setOnAction(e -> {
				refreshTransactions(table, true);
				updateRevenue.run();
			});
			VBox summary = new VBox(12, title, revenue);
			summary.setAlignment(Pos.TOP_CENTER);
			summary.setPadding(new Insets(20));
			summary.setMinWidth(210);
			summary.setMaxWidth(230);
			summary.getStyleClass().add("revenue-card");

			BorderPane layout = new BorderPane();
			layout.setCenter(table);
			layout.setRight(summary);
			BorderPane.setMargin(summary, new Insets(0, 0, 0, 16));
			VBox result = new VBox(12, refresh, layout);
			result.setPadding(new Insets(16));
			VBox.setVgrow(layout, Priority.ALWAYS);
			return result;
		}
	
	private TableView<Transaction> transactionTable(boolean global) {
		TableView<Transaction> table = new TableView<>();
		table.getColumns().add(column("Transaction ID", "id", 170));
		table.getColumns().add(column("Product", "productName", 150));
		table.getColumns().add(column("Quantity", "totalPurchased", 90));
		table.getColumns().add(column("Total", "totalAmount", 100));
		table.getColumns().add(column("Payment", "payment", 100));
		table.getColumns().add(column("Change", "change", 100));
		table.getColumns().add(column("Clerk", "owner", 130));
		table.getColumns().add(column("Voided", "voided", 80));
		refreshTransactions(table, global); return table;
	}
	
	private void refreshTransactions(TableView<Transaction> table, boolean global) {
		ObservableList<Transaction> rows = FXCollections.observableArrayList(global ? appSystem.getAllTransactions() : currentUser.getTransactions());
		rows.sort(Comparator.comparing(Transaction::getId).reversed()); table.setItems(rows);
	}

	
	private VBox inventoryCheckerTab() {
		TableView<Product> table = productTable();
		Button refresh = new Button("Refresh");
		refresh.setOnAction(e -> {
			refreshProducts(table);
		});
		return content(table, new HBox(10, new Label("Inventory"), refresh));
	}
	
	// Chatgpt Suggestion for reusable column adding
	private <S,T> TableColumn<S,T> column(String title, String property, double width) {
		TableColumn<S,T> column = new TableColumn<>(title);
		column.setCellValueFactory(new PropertyValueFactory<>(property)); 
		column.setPrefWidth(width); 
		return column;
	}
}