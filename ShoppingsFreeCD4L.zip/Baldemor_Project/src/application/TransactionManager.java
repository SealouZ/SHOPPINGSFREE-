package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map.Entry;

public class TransactionManager {
	public static int transactions = 0;
	private final String name;
	private HashMap<String, Transaction> transactionHistory;	// Might not use
	
	
	// Constructor
	public TransactionManager(String name) {
		this.name = name;
		this.transactionHistory = new HashMap<>();
	}
	
	
	// Getters & Setters
	public String getName() { return this.name; }
	public HashMap<String, Transaction> getTransactionHistory(){ return new HashMap<>(transactionHistory); }


	// Methods
	public boolean addTransaction(Transaction transaction) {
		if (transaction == null) return false;
		this.transactionHistory.put(transaction.getId(), transaction);
		return true;
	}
	
	// The transactions of a clerk is saved yet not given back the next time the app is opened
	// The clerk transactions are personal and for the day only for ease of daily transaction history
	public void saveHistory(Path historySaveFile) {
		System.out.println("\n\nSaving History. . .");
		try (BufferedWriter writer = Files.newBufferedWriter(historySaveFile)){
			Files.createDirectories(historySaveFile.getParent());
			writer.write(String.valueOf(transactions));
			writer.newLine();
			for (Entry<String, Transaction> transaction: this.transactionHistory.entrySet()) {
				writer.write(String.join("|", transaction.getValue().getId(), transaction.getValue().getProduct().getId(), String.valueOf(transaction.getValue().getTotalPurchased()), String.valueOf(transaction.getValue().getTotalAmount()), String.valueOf(transaction.getValue().getPayment()), String.valueOf(transaction.getValue().getChange()), String.valueOf(transaction.getValue().isVoided()), transaction.getValue().getOwner()));
				writer.newLine();
			}
			System.out.println("History Saved");
			writer.close();
		} catch (IOException e) {
			System.out.println("Save Unsuccessful");
		}
	}
	
	// TODO: LOAD THE PRODUCT CLASS
	public void loadHistory(Path historyFile, Inventory inventory) {
		System.out.println("\nLoading Inventory. . .");
		this.transactionHistory.clear();
		int previousTransactionCount = transactions;
		try (BufferedReader reader = Files.newBufferedReader(historyFile)){
			String line = reader.readLine();
			transactions = Integer.parseInt(line);
			while ((line = reader.readLine()) != null) {
				String[] transactionLine = line.split("\\|", -1);
				Transaction transaction = new Transaction(transactionLine[0], inventory.getProduct(transactionLine[1]), Integer.parseInt(transactionLine[2]), Double.parseDouble(transactionLine[3]),  Double.parseDouble(transactionLine[4]), Double.parseDouble(transactionLine[5]), transactionLine[7]);
				this.transactionHistory.put(transaction.getId(), transaction);
				System.out.println("Item Added");
			}
		} catch (IOException e) {
			transactions = previousTransactionCount;
			System.out.println("Load Unsuccessful");
		}
	}
}
