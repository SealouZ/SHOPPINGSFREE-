package application;

import java.util.ArrayList;
import java.util.List;

public class Clerk extends User{
	
	
	// Constructor
	public Clerk(String username, String name, String userType, String password) { 
		super(username, name, userType, password); 
	}
	
	// Methods
	public List<Transaction> getTransactionHistory() {
		return new ArrayList<>(getTransactions());
	}
}
