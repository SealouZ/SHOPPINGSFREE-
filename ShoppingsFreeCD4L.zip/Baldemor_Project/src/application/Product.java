package application;

public class Product {
	private final String id;
	private String name;
	private int price;
	private int stock;
	private String description;
	
	
	// Constructor
	public Product(String id, String name, int price, int stock, String description) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.stock = stock;
		this.description = description;
	}
	
	
	// Getters & Setters
	public String getId() { return this.id; }
	public String getName() { return this.name; }
	public int getPrice() { return this.price; }
	public int getStock() { return this.stock; }
	public String getDescription() { return this.description; }
	
	public String setName(String newName) { return this.name = newName; }
	public void setPrice(int newPrice) { this.price = newPrice; }
	public void setStock(int newStock) { this.stock = newStock; }
	public String setDescription(String newDesc) { return this.description = newDesc; }
}
