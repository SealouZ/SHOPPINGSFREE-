package application;

import java.util.ArrayList;
import java.util.List;

// import java.util.HashMap;

public class Manager extends User {
//	private HashMap<Clerk, HashMap<Integer, Integer>> clerkSales;	// Hashmap of Clerks' sales
	
	// Constructor
	public Manager(String username, String name, String userType, String password) { 
		super(username, name, userType, password); 
//		this.clerkSales = new HashMap<>();
	}
	
	
	// Methods
	
	
//	public void addClerk(UserDatabase database, Clerk user) {
//		if (this.isManager()) { 
//			database.getUsers().add(user); 		// Add user to the database
//			System.out.println("Successfully added clerk");
//		} else System.out.println("Unable to add clerk");
//	}
//	
//	public void removeClerk(UserDatabase database, Clerk user) {
//		if (this.isManager()) { 
//			database.getUsers().remove(user); 		// Remove user from the database
//			System.out.println("Successfully removed clerk");
//		} else System.out.println("Unable to remove clerk");
//	}
	
	public boolean addProduct(Inventory inventory, Product product) {
		return inventory.addProduct(product); 		// Add item to inventory
	}
	
	public boolean removeProduct(Inventory inventory, Product product) {
		if (product == null) return false;
		return inventory.removeProduct(product.getId()); 		// Remove item from inventory
	}
	
	public boolean restockProduct(Product product, int stock) {
		if (product == null || stock <= 0) return false;
		product.setStock(product.getStock() + stock);
		return true;
	}
	
	public boolean editProductDetails(Product product, String newName, int newPrice, String newDesc) {
		if (product == null || newName == null || newName.isBlank() || newPrice < 0) return false;
		product.setName(newName);
		product.setPrice(newPrice);
		product.setDescription(newDesc);
		return true;
	}
	
	public List<Clerk> getClerks(UserDatabase database) {
		List<Clerk> clerks = new ArrayList<>();
		for (User user : database.getUsers()) {
			if (user instanceof Clerk) {
				clerks.add((Clerk) user);
			}
		}
		return clerks;
	}
	
	public List<Transaction> getAllTransactionHistory(UserDatabase database) {
		List<Transaction> history = new ArrayList<>();
		for (User user : database.getUsers()) {
			history.addAll(user.getTransactions());
		}
		return history;
	}
	
	public double getTotalClerkSales(UserDatabase database) {
		double total = 0;
		for (User user : database.getUsers()) {
			if (user instanceof Clerk) {
				total += user.getSales();
			}
		}
		return total;
	}
}
