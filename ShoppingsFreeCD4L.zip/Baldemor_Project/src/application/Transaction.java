package application;

public class Transaction {
	private final String transactionId;
	private final Product product;
	private final String productId;
	private final int totalPurchased;
	private final double totalAmount;
	private final double payment;
	private final double change;
	private boolean voided;
	private String owner;
	
	
	// Constructor
	public Transaction(String id, Product product, int bought, double total, double payment, double change, String owner) {
		this.transactionId = id;
		this.product = product;
		this.productId = product.getId();
		this.totalPurchased = bought;
		this.totalAmount = total;
		this.payment = payment;
		this.change = change;
		
		this.voided = false;
		this.owner = owner;
	}
	
	
	// Getters & Setters
	public String getId() { return this.transactionId; }
	public Product getProduct() { return this.product; }
	public String getProductId() { return this.productId; }
	public int getTotalPurchased() { return this.totalPurchased; }
	public double getTotalAmount() { return this.totalAmount; }
	public boolean isVoided() { return this.voided; }
	public double getPayment() { return this.payment; }
	public double getChange() { return this.change; }
	public String getOwner() { return this.owner; }
	public String getProductName() {
		if (product == null) return "Product Unavailable";
		return product.getName();
	}
	
	
	// Methods
	public void voidTransaction() { this.voided = true; }
}
