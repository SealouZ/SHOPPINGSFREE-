package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map.Entry;

public class Inventory{
	private final String name;
	private HashMap<String, Product> items;
	
	
	// Constructor
	public Inventory(String name) {
		this.name = name;
		this.items = new HashMap<>();
	}
	
	
	// Getters & Setters
	public String getName() { return this.name; }
	public HashMap<String, Product> getItems() { return new HashMap<>(items); }
	public Product getProduct(String id) { return items.get(id); }
	
	
	// Methods
	public boolean addProduct(Product product) {
		if (product == null || product.getId() == null || items.containsKey(product.getId())){
			return false;
		}
		items.put(product.getId(), product);
		return true;
	}
	
	public boolean removeProduct(String productId) {
		return items.remove(productId) != null;
	}
	
	public boolean containsProduct(String productId) {
		return items.containsKey(productId);
	}
	
	public void saveInventory(Path inventorySaveFile) {
		System.out.println("\n\nSaving Inventory. . .");
		try (BufferedWriter writer = Files.newBufferedWriter(inventorySaveFile)){
			Files.createDirectories(inventorySaveFile.getParent());
			for (Entry<String, Product> item: this.items.entrySet()) {
				writer.write(String.join("|", item.getValue().getId(), item.getValue().getName(), String.valueOf(item.getValue().getPrice()), String.valueOf(item.getValue().getStock()), item.getValue().getDescription()));
				writer.newLine();
			}
			System.out.println("Inventory Saved");
			writer.close();
		} catch (IOException e) {
			System.out.println("Save Unsuccessful");
		}
	}
	
	public void loadInventory(Path saveFile) {
		System.out.println("\nLoading Inventory. . .");
		this.items.clear();
		try (BufferedReader reader = Files.newBufferedReader(saveFile)){
			String line;
			while ((line = reader.readLine()) != null) {
				String[] itemLine = line.split("\\|", -1);
				Product item = new Product(itemLine[0], itemLine[1], Integer.parseInt(itemLine[2]), Integer.parseInt(itemLine[3]), itemLine[4]);
				this.items.put(item.getId(), item);
				System.out.println("Item Added");
			}
		} catch (IOException e) {
			System.out.println("Load Unsuccessful");
		}
	}
	
}
