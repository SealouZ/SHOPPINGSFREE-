package application;

import java.util.ArrayList;

public abstract class User {
	private final String username;
	private final String name;
	private final String userType; 
	private final String password;
	protected ArrayList<Transaction> transactions;	// Personal Transactions
	protected double sales;

	
	// Constructor
	public User(String username, String name, String userType, String password) {
		this.username = username;
		this.name = name;
		this.userType = userType;
		this.password = password;
		this.transactions = new ArrayList<>();
		this.sales = 0;
	}
	
	
	// Getters & Setters
	public String getUsername()	 { return username; }
	public String getName()			{ return name; }
	public String getUserType()	 { return userType; }
	public String getPassword()	 { return password; }
	public ArrayList<Transaction> getTransactions() { return this.transactions; }
	public double getSales() { return this.sales; }
	
	public double setSales(double newSales) { return this.sales = newSales; }
	
	
	// Methods
	public boolean isManager() {
		if (this instanceof Manager) return true;
		return false;
	}
	
	@SuppressWarnings("unused")		// Warning??
	public Transaction sellItem(Product product, int qty, double payment) {
		if (product == null) {
			System.out.println("\nInvalid Product");
			return null;
		}
		if (product.getStock() < qty) {
			System.out.println("\nInsufficient Stock");
			return null;
		} 
		if (qty <= 0) {
			System.out.println("\nInvalid Quantity");
			return null;
		}
		if (payment < 0) {
			System.out.println("\nInvalid Payment");
			return null;
		}
		
		double price = (double)(product.getPrice() * qty);
		
		if (payment < price) return null;
		double change = payment - price;		// Give Change
		product.setStock(product.getStock() - qty);		// Reduce Stock
		this.sales += price;		// Make money
		// Add to the array list with new id
		Transaction transaction = new Transaction(String.join("_", product.getId(), String.valueOf(TransactionManager.transactions + 1)), product, qty, price, payment, change, this.getUsername());
		this.transactions.add(transaction);
		// Call TransactionManager
		UserDatabase.totalRevenue += price;
		TransactionManager.transactions++;
		System.out.printf("\nSold %d %s for %.2f, change of %.2f\n", qty, product.getName(), price, change);
		return transaction;
	}
	
	public boolean voidTransaction(String transactionId) {
		if (transactionId == null) { return false; }
		for (Transaction transaction : transactions) {
			if (transaction.getId().equals(transactionId) && !transaction.isVoided()) {
				// Restore inventory
				Product product = transaction.getProduct();
				if (product == null) return false;
				product.setStock(product.getStock()+ transaction.getTotalPurchased());
				// Reverse sales
				this.sales -= transaction.getTotalAmount();
				UserDatabase.totalRevenue -= transaction.getTotalAmount();
				transaction.voidTransaction();		// Lets me know if transaction is voided
				return true;
			}
		}
		return false;
	}
	
	// TODO: USER DASHBOARD FROM LOGIN
	public User login(UserDatabase users, String username, String password) {
		for (User user: users.getUsers()) {
			if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
				if (user.isManager()) {
					System.out.printf("\nWelcome Manager %s\n", user.getUsername());
				} else {
					System.out.printf("\nWelcome Clerk %s\n", user.getUsername());
				} return user;
			}
		}
		System.out.println("\nIncorrect Credentials");
		return null;
	}
	
}
