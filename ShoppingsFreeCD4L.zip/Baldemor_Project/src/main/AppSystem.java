package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import application.*;

public class AppSystem {
	private final UserDatabase userDatabase;
	private final Inventory inventory;
	private final TransactionManager transactionManager;
	Path saveFile = Paths.get("src/application/users.txt");
	Path inventorySaveFile = Paths.get("src/application/inventory.txt");
	Path transactionsSaveFile = Paths.get("src/application/transactionHistory.txt");

	
	// Constructor
	public AppSystem() {
		this.userDatabase = new UserDatabase("Main Database");
		this.inventory = new Inventory("Main Inventory");
		this.transactionManager = new TransactionManager("Transaction History");
		loadAll();
	}
	
	
	// Getters & Setters
	public UserDatabase getUserDatabase() { return this.userDatabase; }
	public Inventory getInventory() { return this.inventory; }
	public TransactionManager getTransactionManager() { return this.transactionManager; }
	
	
	// Methods
	public void loadAll() {
		userDatabase.loadData(saveFile);
		inventory.loadInventory(inventorySaveFile);
		loadTransactions();
	}
	
	public void saveAll() {
		userDatabase.saveData(saveFile);
		inventory.saveInventory(inventorySaveFile);
		saveTransactions();
	}
	
	public User login(String username, String password) {
		User currUser = userDatabase.login(username, password);
		return currUser;
	}
	
	public User signup(String username, String name, String password, String userType) {	
		// For input
		if (username == null || username.isBlank() || name == null || name.isBlank() || password == null || password.isBlank()) {
			return null;
		}
		
		if (userDatabase.findUser(username.trim()) != null) { return null; }
		
		// Add depende sa type
		User newUser;
		if ("Manager".equals(userType)) {
			newUser = new Manager(username.trim(), name, "Manager", password);
			userDatabase.addManager((Manager)newUser);;
		} else if ("Clerk".equals(userType)){
			newUser = new Clerk(username.trim(), name, "Clerk", password);
			userDatabase.addClerk((Clerk)newUser);
		} else return null;
		saveAll();
		return newUser;
	}
	
	public List<Transaction> getAllTransactions() {
		HashMap<String, Transaction> allTransactions = new HashMap<>();
		allTransactions.putAll(transactionManager.getTransactionHistory());
		for (User user : userDatabase.getUsers()) {
			for (Transaction transaction : user.getTransactions()) {
				allTransactions.put(transaction.getId(), transaction);
			}
		}
		return new ArrayList<>(allTransactions.values());
	}
	
	public ArrayList<Transaction> getUserTransactions(User user) {
		if (user == null) return null;
		return new ArrayList<>(user.getTransactions());
	}
	
	// Pang retrace for history
	public User findTransactionOwner(Transaction transactionOwner) {
		if (transactionOwner == null) return null;
		for (User user : userDatabase.getUsers()) {
			for (Transaction transaction : user.getTransactions()) {
				if (transaction.getId().equals(transactionOwner.getId())) return user;
			}
		} return null;
	}
	
	public boolean voidTransaction(String transactionId) {
		if (transactionId == null) return false;
		for (User user : userDatabase.getUsers()) {
			for (Transaction transaction : user.getTransactions()) {
				if (transactionId.equals(transaction.getId())) return user.voidTransaction(transactionId);
			}
		} return false;
	}
	
	private void saveTransactions() {
		try (BufferedWriter writer = Files.newBufferedWriter(transactionsSaveFile)) {
			writer.write(String.valueOf(TransactionManager.transactions));
			writer.newLine();
			for (Transaction transaction : getAllTransactions()) {
				writer.write(String.join("|", transaction.getId(), transaction.getProduct().getId(), String.valueOf(transaction.getTotalPurchased()), String.valueOf(transaction.getTotalAmount()), String.valueOf(transaction.getPayment()), String.valueOf(transaction.getChange()), String.valueOf(transaction.isVoided()), transaction.getOwner()));
				writer.newLine();
			} writer.close();
		} catch (IOException e) {
			System.out.println("Unable to save transaction history");
		}
	}
	
	private void loadTransactions() {
		HashMap<String, Transaction> loaded = new HashMap<>();
		
		transactionManager.getTransactionHistory().clear();
		transactionManager.getTransactionHistory().clear();
		for (User user : userDatabase.getUsers()) {
			user.getTransactions().clear();
			user.setSales(0);
		}
		int previousTransactionCount = TransactionManager.transactions;
		TransactionManager.transactions = 0;
		
		try (BufferedReader reader = Files.newBufferedReader(transactionsSaveFile)) {
			String line = reader.readLine();
			TransactionManager.transactions = Integer.parseInt(line);
			while ((line = reader.readLine()) != null) {
				String[] transactionLine = line.split("\\|", -1);
				String username = transactionLine[7];
				boolean voided = Boolean.parseBoolean(transactionLine[6]);
				double total = Double.parseDouble(transactionLine[3]);
				
				Transaction transaction = new Transaction(transactionLine[0], inventory.getProduct(transactionLine[1]), Integer.parseInt(transactionLine[2]), Double.parseDouble(transactionLine[3]),  Double.parseDouble(transactionLine[4]), Double.parseDouble(transactionLine[5]), username);
				
				if (voided) transaction.voidTransaction();
				loaded.put(transaction.getId(), transaction);
				
				User owner = userDatabase.findUser(username);
				if (owner != null) {
					owner.getTransactions().add(transaction);
					if (!voided) {
						owner.setSales(owner.getSales() + total);
					}
				}
			}
		} catch (IOException e) {
			TransactionManager.transactions = previousTransactionCount;
			System.out.println("Unable to load transaction history");
		}
	}
}