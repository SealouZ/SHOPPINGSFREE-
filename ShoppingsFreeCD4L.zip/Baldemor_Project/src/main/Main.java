package main;
	
import java.nio.file.Path;
import java.nio.file.Paths;

import application.Clerk;
import application.Inventory;
import application.Manager;
import application.Product;
import application.Transaction;
import application.TransactionManager;
import application.UserDatabase;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Main extends Application{	// extends Application
	private AppSystem appSystem;
	
	public static void main(String[] args){
		launch(args);
		
		
//		Path saveFile = Paths.get("src/application/users.txt");
//		Path inventorySaveFile = Paths.get("src/application/inventory.txt");
//		Path transactionSaveFile = Paths.get("src/application/transactionHistory.txt");
//		UserDatabase users = new UserDatabase("Main Database");
//		Inventory items = new Inventory("Main Inventory");
//		TransactionManager transactionHistory = new TransactionManager("Transaction History");
//		users.loadData(saveFile);
//		items.loadInventory(inventorySaveFile);
// 		transactionHistory.loadHistory(transactionSaveFile, items);
//		
//		Manager jeron = new Manager("Jeron", "Jayron Baldemor", "Manager", "password");
//		Manager gian = new Manager("Lidontno", "Gian Karl Ramos", "Manager", "password2");
//		Manager zeke = new Manager("Zeke", "Dennis Ezekiel Vidar", "Manager", "password3");
//		Clerk jeboy = new Clerk("Jeboy", "Jose Enrique Velasco", "Clerk", "password4");
//		Clerk joash = new Clerk("Stellqr", "Joash Edrick Landicho", "Clerk", "password5");
////		users.addManager(jeron);
////		users.addManager(gian);
////		users.addManager(zeke);
////		users.addClerk(jeboy);
////		users.addClerk(joash);
//		
//		jeron.login(users, "Jeron", "password");
//		jeron.login(users, "eqefqefq", "password");	// Incorrect
//		jeron.login(users, "Jeron", "awdadsdaw");	// Incorrect
//		jeboy.login(users, "Jeboy", "password4");
//		
//		Product mango = new Product("F001", "Mango", 258, 0, "Sweet and Yummy");
//		Product eggplant = new Product("V001", "Eggplant", 100, 0, "Talooong");
//		Product jackfruit = new Product("F002", "Jackfruit", 300, 0, "Spike fruit");
//		Product onion = new Product("V002", "Onion", 125, 0, "Relapse fruit");
////		jeron.addProduct(items, mango);
////		zeke.addProduct(items, eggplant);
////		gian.addProduct(items, jackfruit);
////		jeron.addProduct(items, onion);
//		
//		
//		jeron.sellItem(onion, 4, 200);
//		jeron.restockProduct(onion, 12);
//		jeron.restockProduct(eggplant, 8);
//		zeke.restockProduct(mango, 5);
//		zeke.restockProduct(jackfruit, 10);
////		transactionHistory.addTransaction(jeboy.sellItem(onion, 3, 500));
////		transactionHistory.addTransaction(jeboy.sellItem(eggplant, 9, 1250));
////		transactionHistory.addTransaction(jeboy.sellItem(eggplant, 8, 1250));
////		transactionHistory.addTransaction(jeboy.sellItem(onion, 1, 200));
//		jeboy.voidTransaction("V001_2");
//		System.out.printf("\nJeron: %.2f", jeron.getSales());
//		System.out.printf("\nJeboy: %.2f", jeboy.getSales());
//		for (Transaction transaction : jeboy.getTransactions()) {
//			System.out.printf("\n%s: %s %.2f", transaction.getId(), transaction.getProduct().getName(), transaction.getTotalAmount());
//		}
//		
//		users.saveData(saveFile);
//		items.saveInventory(inventorySaveFile);
//		transactionHistory.saveHistory(transactionSaveFile);
	}
	
	@Override
	public void start(Stage primaryStage) {
        appSystem = new AppSystem();

        Dashboard dashboard = new Dashboard(appSystem, primaryStage);
        Scene scene = new Scene(dashboard, 1220, 780);
        scene.getStylesheets().add(getClass().getResource("/application/application.css").toExternalForm());

        primaryStage.setTitle("Agriculture Data Management System");
        primaryStage.setMinWidth(980);
        primaryStage.setMinHeight(650);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @Override
    public void stop() {
        if (appSystem != null) {
            appSystem.saveAll();
        }
    }

}
