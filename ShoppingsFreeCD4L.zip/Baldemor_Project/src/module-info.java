module Baldemor_Project {

    requires javafx.controls;
    requires javafx.graphics;

    exports main;
    opens main to javafx.graphics;

    opens application to javafx.graphics, javafx.fxml, javafx.base;

}